import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon, 
  Clock, 
  Plus, 
  MapPin, 
  Music as MusicIcon,
  Mic,
  Image as ImageIcon,
  SmilePlus
} from 'lucide-react';
import { Memory, DayReaction } from '../lib/gemini';

interface CalendarViewProps {
  memories: Memory[];
  dayReactions: DayReaction[];
  onUpdateDayReaction: (date: string, emoji: string) => void;
  onClose: () => void;
  onAddMemoryAtDate: (date: string) => void;
}

export default function CalendarView({ 
  memories, 
  dayReactions,
  onUpdateDayReaction,
  onClose, 
  onAddMemoryAtDate 
}: CalendarViewProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());

  const daysInMonth = (year: number, month: number) => new Date(year, month + 1, 0).getDate();
  const firstDayOfMonth = (year: number, month: number) => new Date(year, month, 1).getDay();

  const prevMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  const nextMonth = () => setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  const days = Array.from({ length: daysInMonth(year, month) }, (_, i) => i + 1);
  const blanks = Array.from({ length: firstDayOfMonth(year, month) }, (_, i) => i);

  const getMemoriesForDate = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return memories.filter(m => m.date.startsWith(dateStr));
  };

  const getReactionForDate = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return dayReactions.find(r => r.date === dateStr)?.emoji;
  };

  const commonEmojis = ['✨', '❤️', '🌙', '🍃', '🌊', '🕯️', '🎞️', '☕'];

  const selectedDateStr = selectedDate ? `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDate.getDate()).padStart(2, '0')}` : '';
  const selectedMemories = memories.filter(m => m.date.startsWith(selectedDateStr));
  const selectedReaction = dayReactions.find(r => r.date === selectedDateStr)?.emoji;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9000] bg-black/95 backdrop-blur-xl flex flex-col md:flex-row overflow-hidden"
    >
      {/* Left Side: Calendar Grid */}
      <div className="w-full md:w-[400px] lg:w-[500px] h-full flex flex-col border-r border-white/10 p-8">
        <div className="flex items-center justify-between mb-12">
          <button onClick={onClose} className="flex items-center gap-2 text-white/60 hover:text-white transition-colors group">
            <ChevronLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
            <span className="font-hand text-lg">Back to Vault</span>
          </button>
          <div className="flex items-center gap-4">
            <button onClick={prevMonth} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronLeft size={20} className="text-white" />
            </button>
            <h2 className="font-serif text-2xl text-white italic min-w-[140px] text-center">{monthName} {year}</h2>
            <button onClick={nextMonth} className="p-2 hover:bg-white/10 rounded-full transition-colors">
              <ChevronRight size={20} className="text-white" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 mb-4">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
            <div key={d} className="text-center text-[10px] uppercase tracking-widest text-white/40 font-hand">{d}</div>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-2 flex-1">
          {blanks.map(b => <div key={`blank-${b}`} />)}
          {days.map(d => {
            const dateMemories = getMemoriesForDate(d);
            const isSelected = selectedDate?.getDate() === d && selectedDate?.getMonth() === month && selectedDate?.getFullYear() === year;
            const isToday = new Date().getDate() === d && new Date().getMonth() === month && new Date().getFullYear() === year;

            return (
              <button
                key={d}
                onClick={() => setSelectedDate(new Date(year, month, d))}
                className={`aspect-square relative flex flex-col items-center justify-center rounded-xl transition-all group ${isSelected ? 'bg-dusty-rose text-white shadow-[0_0_20px_rgba(196,130,130,0.4)]' : 'hover:bg-white/5 text-white/80'}`}
              >
                <span className={`text-lg font-hand ${isToday && !isSelected ? 'text-dusty-rose' : ''}`}>{d}</span>
                
                {getReactionForDate(d) && (
                  <span className="absolute top-1 right-1 text-[10px]">{getReactionForDate(d)}</span>
                )}

                {dateMemories.length > 0 && (
                  <div className={`absolute bottom-2 w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : 'bg-dusty-rose'}`} />
                )}
                {isSelected && (
                  <motion.div 
                    layoutId="calendar-glow"
                    className="absolute inset-0 rounded-xl bg-white/10 blur-md -z-10"
                  />
                )}
              </button>
            );
          })}
        </div>

        <button 
          onClick={() => selectedDate && onAddMemoryAtDate(selectedDateStr)}
          className="mt-8 w-full py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl flex items-center justify-center gap-3 text-white transition-all group"
        >
          <Plus size={18} className="group-hover:rotate-90 transition-transform" />
          <span className="font-hand text-lg">Add Memory for {selectedDate?.toLocaleDateString()}</span>
        </button>
      </div>

      {/* Right Side: Timeline / Selected Date Details */}
      <div className="flex-1 h-full overflow-y-auto p-8 lg:p-16 bg-gradient-to-br from-black to-zinc-900">
        <div className="max-w-2xl mx-auto">
          <div className="mb-12">
            <h1 className="font-serif text-5xl text-white italic mb-2">
              {selectedDate?.toLocaleDateString('default', { weekday: 'long', month: 'long', day: 'numeric' })}
            </h1>
            <p className="font-hand text-xl text-white/40 italic">
              {selectedMemories.length === 0 ? "No memories captured on this day yet." : `${selectedMemories.length} moments preserved.`}
            </p>
          </div>

          {/* Emoji Reaction Selector */}
          <div className="mb-12 bg-white/5 border border-white/10 rounded-3xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <SmilePlus size={18} className="text-dusty-rose" />
              <span className="font-hand text-lg text-white/60">How did this day feel?</span>
            </div>
            <div className="flex flex-wrap gap-3">
              {commonEmojis.map(emoji => (
                <button
                  key={emoji}
                  onClick={() => selectedDateStr && onUpdateDayReaction(selectedDateStr, emoji)}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl transition-all hover:scale-110 ${selectedReaction === emoji ? 'bg-dusty-rose/20 border border-dusty-rose/40 scale-110' : 'bg-white/5 border border-white/5 hover:bg-white/10'}`}
                >
                  {emoji}
                </button>
              ))}
              {selectedReaction && (
                <button 
                  onClick={() => selectedDateStr && onUpdateDayReaction(selectedDateStr, '')}
                  className="text-[10px] text-white/20 hover:text-white/40 font-hand uppercase tracking-widest ml-auto"
                >
                  Clear
                </button>
              )}
            </div>
          </div>

          <div className="space-y-12 relative before:absolute before:left-6 before:top-2 before:bottom-2 before:w-[1px] before:bg-white/10">
            {selectedMemories.length > 0 ? (
              selectedMemories.map((mem, idx) => (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  key={mem.id}
                  className="relative pl-16 group"
                >
                  <div className="absolute left-4 top-2 w-4 h-4 rounded-full bg-dusty-rose shadow-[0_0_15px_rgba(196,130,130,0.6)] z-10" />
                  
                  <div className="bg-white/5 border border-white/10 rounded-3xl p-6 hover:bg-white/10 transition-all hover:scale-[1.02] hover:shadow-[0_20px_40px_rgba(0,0,0,0.4)] group">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 text-white/40 text-xs uppercase tracking-widest mb-1">
                          <Clock size={12} />
                          <span>{new Date(mem.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          {mem.location && (
                            <>
                              <span className="mx-1">•</span>
                              <MapPin size={12} />
                              <span>{mem.location}</span>
                            </>
                          )}
                        </div>
                        <h3 className="font-serif text-2xl text-white italic">{mem.title}</h3>
                      </div>
                      <div className="flex gap-2">
                        {mem.type === 'photo' && <ImageIcon size={18} className="text-dusty-rose" />}
                        {mem.type === 'voice' && <Mic size={18} className="text-dusty-rose" />}
                        {mem.type === 'music' && <MusicIcon size={18} className="text-dusty-rose" />}
                      </div>
                    </div>

                    {mem.photoUrl && (
                      <div className="aspect-video rounded-2xl overflow-hidden mb-4 grayscale-[0.5] group-hover:grayscale-0 transition-all duration-700">
                        <img src={mem.photoUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                    )}

                    <p className="text-white/70 font-hand text-lg leading-relaxed mb-4">{mem.desc}</p>

                    {mem.music && (
                      <div className="flex items-center gap-4 bg-black/40 p-3 rounded-2xl border border-white/5">
                        <div className="w-12 h-12 rounded-lg bg-zinc-800 flex items-center justify-center overflow-hidden">
                          {mem.music.albumArt ? (
                            <img src={mem.music.albumArt} className="w-full h-full object-cover" />
                          ) : (
                            <MusicIcon size={20} className="text-white/20" />
                          )}
                        </div>
                        <div>
                          <div className="text-white font-medium text-sm">{mem.music.song}</div>
                          <div className="text-white/40 text-xs">{mem.music.artist}</div>
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              ))
            ) : (
              <div className="pl-16 py-12">
                <div className="bg-white/5 border border-dashed border-white/10 rounded-3xl p-12 text-center">
                  <CalendarIcon size={48} className="mx-auto text-white/10 mb-4" />
                  <p className="text-white/40 font-hand text-xl italic">A quiet day in the vault...</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
